import {combineReducers} from "redux"
import auth from './common/auth'

let allReducer  = {
    auth
}

let reducers = combineReducers(allReducer)
export default reducers